# Agent A golden case49-v174-red — 9b40a87

- Evaluación parcial: 2/4 turnos aprobados en 1 casos; no acredita aceptación completa de 48 turnos.
- SHA evaluado: `9b40a87b1b9523df4f2658ca1450c43a84f86cd9`
- Origen de la línea de base de autoridad: `028f272fc3a6f6dc4806d19b251564169b55e6d6`
- Brain: `studyx-agent-a-brain-v174`
- Prompt canónico: `studyx-agent-a-canonical-v109`
- Modelo interno del agente: `deepseek-v4-flash`
- Proveedor/modelo de evaluación: `deepseek` / `deepseek-v4-flash`
- Modelo del juez: `deepseek-v4-flash` (constante en la comparación oficial)
- Llamadas/intentos al proveedor: 8 / 8
- Tokens: entrada 109301, salida 1769, total 111070
- Recuperaciones de formato del juez: 0; originales y diagnóstico conservados en el JSON por turno.
- Casos: 0 aprobados; 1 fallidos; 0 con error del evaluador
- Turnos (4): 2 aprobados; 2 fallidos; 0 sin veredicto (approved=null, de los cuales 0 con error del evaluador)

| Caso/turno | Resultado | Autoridad | Borradores originales y reparaciones | Texto entregado al transporte | Move / acción | Rechazos backend | Hipótesis de capa |
|---|---|---|---|---|---|---|---|
| 49_broad_area_unanswered_discovery_20261106/d01_greeting | APROBADO | docs/authority/prompt-agente-a-studyx-v2.md:7 \| En el primer contacto preséntate una vez con «Soy {{NOMBRE_ASESOR}}, asesora de Studyx». Conserva nombre, rol y marca; varía naturalmente el saludo y la transición sin repetir una frase fija. No añadas «Academia Internacional», calificativos tecnológicos ni experiencias personales. | Intento 1: Hola, todo bien por acá. Soy Emma, asesora de Studyx. Cuéntame, qué te gustaría aprender o qué curso tenías en mente? | Hola, todo bien por acá. Soy Emma, asesora de Studyx. Cuéntame, qué te gustaría aprender o qué curso tenías en mente? | greeting / {"type":"none"} | [] | — |
| 49_broad_area_unanswered_discovery_20261106/d02_acknowledgement | APROBADO | docs/authority/prompt-agente-a-studyx-v2.md:17 \| Elige uno o dos mensajes breves; no fuerces dos si uno basta. Una idea por mensaje, sin párrafos largos. Nunca hagas más de una pregunta principal por intervención. Varía la estructura: responde, reacciona, profundiza, retoma algo o propone; no uses plantillas. Antes de entregar, comprueba si esto lo escribiría una vendedora real y segura por WhatsApp; si suena genérico, frío, administrativo, sumiso o repetitivo, reescríbelo con menos palabras sin alterar hechos ni acciones. | Intento 1: Perfecto. Para ir directo a lo que te sirve, qué te gustaría aprender o en qué área te gustaría formarte? | Perfecto. Para ir directo a lo que te sirve, qué te gustaría aprender o en qué área te gustaría formarte? | unknown / {"type":"none"} | [] | — |
| 49_broad_area_unanswered_discovery_20261106/d03_does_not_remember | FALLIDO | docs/authority/prompt-agente-a-studyx-v2.md:36 \| ## Descubrir lo justo | Intento 1: Tranquilo, no hace falta que lo recuerdes. Cuéntame en qué área te gustaría formarte y te oriento: oficios, salud y bienestar, gastronomía, negocios, marketing, diseño informático, moda y belleza, emprendedores o cultural. | Tranquilo, no hace falta que lo recuerdes. Cuéntame en qué área te gustaría formarte y te oriento: oficios, salud y bienestar, gastronomía, negocios, marketing, diseño informático, moda y belleza, emprendedores o cultural. | browse_catalog / {"type":"none"} | [] | bonificación |
| 49_broad_area_unanswered_discovery_20261106/d04_computers_options | FALLIDO | docs/authority/prompt-agente-a-studyx-v2.md:21 \| Formato: con dos mensajes, el primero suele responder y el segundo avanzar. Para dos o más opciones usa una lista, una opción por línea, en un solo mensaje. | Intento 1: Claro, en computación tienes varias opciones:<br>Armado y Reparación de PC<br>Reparación de Celulares<br>Redes Informáticas<br>Diseño Gráfico con Photoshop<br>Diseño Gráfico con Illustrator<br>Diseño Gráfico con Corel Draw<br>AutoCAD orientado al Diseño de Interiores | Claro, en computación tienes varias opciones:<br>Armado y Reparación de PC<br>Reparación de Celulares<br>Redes Informáticas<br>Diseño Gráfico con Photoshop<br>Diseño Gráfico con Illustrator<br>Diseño Gráfico con Corel Draw<br>AutoCAD orientado al Diseño de Interiores | browse_catalog / {"type":"none"} | [] | prompt |

## Fallos

- **49_broad_area_unanswered_discovery_20261106/d03_does_not_remember — bonificación:** SEMANTIC_MUST_FAILED [docs/authority/prompt-agente-a-studyx-v2.md:40 | Descubre sólo lo que te sirve para vender: **para qué lo quiere** (objetivo), **por qué ahora** (motivación), **dónde está hoy** (situación o experiencia) y **qué lo puede frenar**. Hazlo conversando, una pregunta por vez, nacida de lo último que dijo. No es un formulario: si ya lo dijo, no lo preguntes. Si el contexto alcanza, avanza. Lo ya respondido está en `commercial_state.sales_profile` (objetivo, experiencia, objeciones, preferencia de canal, bonificados): úsalo y no lo vuelvas a preguntar.]: Acepta que no recuerda, pero en lugar de una sola pregunta útil presenta un menú largo de áreas, lo que incumple el límite de una pregunta sin menú largo.
- **49_broad_area_unanswered_discovery_20261106/d04_computers_options — prompt:** SEMANTIC_MUST_FAILED [docs/authority/prompt-agente-a-studyx-v2.md:50 | Recomienda **un** curso con seguridad, con uno o dos motivos verificados conectados a lo que dijo. No dejes un menú abierto: si duda entre dos, elige tú el que mejor encaja y di por qué.]: La respuesta entrega una lista plana de siete cursos sin diferenciarlos brevemente ni terminar con una sola pregunta nueva que ayude a elegir; no responde al pedido con hasta tres caminos diferenciados. | SEMANTIC_MUST_NOT_FAILED [docs/authority/prompt-agente-a-studyx-v2.md:50 | Recomienda **un** curso con seguridad, con uno o dos motivos verificados conectados a lo que dijo. No dejes un menú abierto: si duda entre dos, elige tú el que mejor encaja y di por qué.]: Se da una lista plana de siete cursos, superando el límite de cuatro o más cursos prohibido.

## Evidencia de entorno y precondiciones


## Comparación con baseline-v8

- Ambas corridas usan el mismo proveedor (deepseek); compartir un alias solicitado no garantiza el mismo snapshot. Las diferencias de una muestra no se atribuyen por sí solas al agente.
- Casos: 0 mejoraron, 0 retrocedieron, 0 sin cambio.
- Turnos: 0 mejoraron, 0 retrocedieron, 0 sin cambio, 0 faltantes.

| Caso/turno | v8 | Corrida actual | Cambio |
|---|---:|---:|---|
